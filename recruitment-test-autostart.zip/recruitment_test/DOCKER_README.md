# Docker: внутренний однохостовый пилот

Подготовлено на основе hh_recruitment_project_three_fixes.zip. Использован прикреплённый ZIP, а не содержимое SharePoint: ссылка не отдала файл.
Основная логика, интерфейс, промпты, схема БД, watchdog и транзакционные исправления сохранены.
Это комплект исходников для сборки, НЕ готовый tar с образами и НЕ подтверждённая контейнерная приёмка.
Текущие результаты: DOCKER_TEST_REPORT.txt. Старые отчёты описывают предыдущие версии.

## Состав и размер

- Dockerfile, target app: Python 3.12 slim, Python-зависимости и исходники. Chromium и npm отсутствуют.
- browser_service/Dockerfile: Node 22 slim, Playwright 1.58.0 и только Chromium headless shell. Firefox/WebKit и полный headed Chromium не устанавливаются.
- Dockerfile, target maintenance: тот же app плюс PostgreSQL client 16. Только для бэкапов.
- PostgreSQL 16: отдельный официальный образ, отдельный постоянный volume.
- Web и оба типа workers используют ОДИН recruitment-app:docker1. Масштабирование не создаёт новые образы.
- Экспорт всех образов одним docker save сохраняет общие слои; export_images.py сжимает результат gzip.

Фактический размер НЕ измерен: сборщика Docker в среде подготовки нет. Python Playwright всё равно содержит свой драйвер, поэтому образ не будет размером с один скрипт. Зависимости имеют исходные диапазоны версий, кроме Playwright; для воспроизводимых релизов после приёмки зафиксируйте lock/digests и сохраните проверенные образы. Не пересобирайте один тег для разных релизов.

## Требования

Linux containers, Docker Engine/Desktop с Compose v2 и BuildKit. На Windows переключите Docker Desktop в Linux containers.
По умолчанию платформа linux/amd64. Для ARM64 задайте TARGET_PLATFORM=linux/arm64 в окружении Compose и соберите заново. Архитектура сборки должна соответствовать серверу.
На сервере нужны доступ в интернет к HH/ИИ/Gmail/Google, корпоративное разрешение на обработку данных и защищённый вход перед приложением.
Предложение для начала: 4 vCPU, 8 ГБ RAM, свободный диск под образы/БД/бэкапы. Это ориентир, не измеренная ёмкость. Старт: 2 general и 1 browser.

## 1. Подготовка в ОТДЕЛЬНОЙ папке

Не заменяйте рабочую Windows-папку и не удаляйте её .env, .env.stage2, .env.infrastructure, БД или бэкапы.
Сначала завершите задачи и проверьте неоднозначные отправки. Перед окончательным переносом остановите старый supervisor и сделайте проверенный PostgreSQL dump. Не запускайте старую и новую установку одновременно с одними HH-токенами: файловая блокировка между разными машинами не действует.

Из новой папки проекта, PowerShell:

```powershell
py -3.12 .\docker\prepare.py --source-env "C:\Users\user\Documents\hh_recruitment_project_final\.env"
```

Введите Gmail app password скрыто. Скрипт создаёт deploy/secrets и deploy/backups, генерирует отдельные пароли новой контейнерной БД и не меняет существующую БД. При повторном запуске не перезаписывает секреты.
На Linux используйте python3 вместо py -3.12.

Защитите deploy средствами Windows ACL либо Linux permissions. Секретные файлы для non-root процессов имеют mode 0444, но находятся внутри host-каталогов mode 0700. Это нужно для Compose bind-mounted secrets с разными UID; на Windows chmod не заменяет ACL. Не делайте родительские каталоги общедоступными. Администраторы Docker могут прочитать секреты.

Исходный .env копируется только как seed. init-config переносит HH/ИИ/Gmail-настройки по списку разрешённых ключей, исключая старые DB/Browser адреса и пароль Gmail. Пароль Gmail подключается отдельным secret. Проверьте, что исходный .env содержит GMAIL_USER, EMPLOYER_ID, HH_CLIENT_ID, HH_CLIENT_SECRET, HH_REDIRECT_URI, действующие HH_BEARER/HH_REFRESH_TOKEN и настройки ИИ.
.env.stage2 и .env.infrastructure в контейнеры НЕ копируются. Windows-пути и localhost из них не подходят отдельным контейнерам.

## 2. Сборка

```powershell
docker compose --profile maintenance build web browser backup
docker compose pull db
docker compose --profile admin --profile maintenance config --quiet
```

Продолжайте только если каждая команда завершилась успешно. Для сборки нужен доступ к Python/npm/Playwright/Debian/PGDG registries. Внутри рабочих контейнеров ничего не скачивается.

## 3. База: выберите правильный сценарий

Сначала запускается ТОЛЬКО новая контейнерная PostgreSQL:

```powershell
docker compose up -d --no-build --pull never db
```

### А. Новый тестовый стенд без рабочей истории

Если намеренно начинаете с пустой тестовой БД:

```powershell
docker compose --profile admin run --rm --no-deps --pull never bootstrap
```

Создаёт схему и роли recruitment_app (DML-only), recruitment_backup (read-only). Административный пароль не передаётся web/workers.
Не используйте этот сценарий как замену переносу рабочей истории: без неё защита от прежних повторов отсутствует.

### Б. Перенос вашей существующей PostgreSQL 16

До запуска web/workers перенесите проверенный dump из ОСТАНОВЛЕННОЙ старой установки в deploy/source.dump. Не копируйте каталог данных PostgreSQL Windows в Linux volume.
Убедитесь, что контейнерная recruitment НОВАЯ и ПУСТАЯ:

```powershell
docker compose exec db psql -U postgres -d recruitment -Atc "SELECT COUNT(*) FROM pg_tables WHERE schemaname='public'"
```

Должно быть 0. Если не 0, ОСТАНОВИТЕСЬ: не восстанавливайте поверх существующих таблиц и не удаляйте volume ради обхода ошибки.

```powershell
docker compose cp .\deploy\source.dump db:/tmp/source.dump
docker compose exec db pg_restore -U postgres -d recruitment --no-owner --no-privileges --exit-on-error /tmp/source.dump
```

При ошибке остановитесь и сохраните журнал. Не запускайте приложение с частично восстановленной БД. Восстановление проверяется в новой отдельной БД, без --clean и без удаления рабочей БД.
После успешного восстановления сравните таблицы и количество строк с исходной копией. Затем настройте роли:

```powershell
docker compose --profile admin run --rm --no-deps --pull never bootstrap
```

Старая установка остаётся выключенной. Старая БД сохраняется для отката. Cookie-владелец задач привязан к профилю браузера и адресу сайта: при смене адреса старые задачи могут быть недоступны из новой cookie-сессии. Записи дедупликации сохраняются. Не меняйте owner_session вручную и не удаляйте историю для открытия старых задач.

## 4. Запуск и приёмка

```powershell
docker compose up -d --no-build --pull never --scale worker-general=2 --scale worker-browser=1
docker compose ps
docker compose logs --tail 80 browser web worker-general worker-browser
docker compose run --rm --no-deps --pull never web smoke-browser
docker compose run --rm --no-deps --pull never web check-gmail
Invoke-RestMethod "http://127.0.0.1:8765/health/ready" | ConvertTo-Json
```

Ожидается REMOTE_BROWSER_ISOLATION_OK, GMAIL_AUTH_OK и ready=true. Проверка Gmail не отправляет письмо. Проверьте одну задачу на свой адрес, отсутствие дублей, экран ручной проверки и восстановление после штатного перезапуска на тестовых данных.
Веб-интерфейс: http://localhost:8765 на сервере. Порты БД 5432 и браузера 3000/3001 на хост НЕ публикуются.
BROWSER_MAX_SESSIONS=1. При увеличении browser workers увеличивайте этот лимит отдельно в compose.yaml, только после измерений. Значение 16+8 не является подтверждённой производительностью.

### Если браузер не запускается

Chromium sandbox включён; browser работает не от root. docker/browser-seccomp.json является пользовательским allowlist-профилем, НЕ скачанной официальной копией Docker/Playwright. Он допускает clone/setns/unshare для user namespaces, блокирует неразрешённые syscalls; clone3 возвращает ENOSYS для fallback.
Профиль и sandbox не проверены в Docker здесь. На целевом Linux-хосте администратор должен проверить поддержку user namespaces, seccomp и ограничения AppArmor. При необходимости заменить профиль на согласованный корпоративный профиль на основе официального Docker/Playwright. Не используйте privileged, SYS_ADMIN, seccomp=unconfined и --no-sandbox для обхода ошибки. Не запускайте рабочие данные до smoke-browser.
Headless shell уменьшает образ, но не гарантирует совместимость реальной Google-проверки. Ручной экран приложения сохранён; noVNC/Xvfb и автоматическое решение CAPTCHA не добавлены. Если нужен headed Chromium, это отдельная более тяжёлая конфигурация, не простая смена BROWSER_HEADLESS=false.

## 5. Бэкапы

```powershell
docker compose --profile maintenance up -d --no-build --pull never init-backups backup
docker compose logs --tail 40 backup
```

Ожидается BACKUP_RESTORE_VERIFIED. Backup повторяется ежедневно, при ошибке через 5 минут. Проверка восстанавливает dump во временную БД, не поверх рабочей. В maintenance-образе pg_dump/pg_restore версии 16. Init-backups только назначает UID 10001 права на выделенный deploy/backups. На Linux доступ к этой папке после chown может требовать sudo.
Для разового запуска после инициализации каталога:

```powershell
docker compose --profile maintenance run --rm --no-deps --pull never backup backup
```

Храните копии вне сервера. Бэкап PostgreSQL НЕ содержит актуальные HH-токены. Они находятся в volume recruitment_hhconfig и обновляются атомарно всеми процессами на одном хосте.
При остановленных web/workers сохраните также hh.env через docker compose cp из существующего web-контейнера:

```powershell
docker compose stop web worker-general worker-browser
docker compose cp web:/config/hh.env .\deploy\hh.env.backup
```

Защитите эту копию. Для возобновления используйте команду запуска с прежними scale. Seed не перезаписывает обновлённые токены. Изменение deploy/secrets/hh_seed после первой инициализации не меняет уже существующий hh.env; для смены настроек администратор должен обновить файл в volume при остановленных процессах, сохранив владельца и атомарную замену. Не удаляйте volume для смены настроек.

## 6. Передача администратору именно ОБРАЗОВ

После сборки и проверки на машине сборки:

```powershell
py -3.12 .\docker\export_images.py
```

Получите recruitment-images.tar.gz и recruitment-images.tar.gz.sha256. Экспорт включает app, browser, maintenance и PostgreSQL. Секреты и данные volumes не входят в образы. Не используйте docker commit контейнера с рабочими данными.
Передайте администратору:
1. recruitment-images.tar.gz и SHA-256;
2. этот исходный ZIP с compose.yaml, docker/browser-seccomp.json и инструкцией;
3. секреты и проверенный dump ТОЛЬКО отдельным согласованным защищённым каналом, если переносится рабочая установка. Предпочтительно создавать секреты на целевом сервере.

На сервере Linux:

```bash
sha256sum -c recruitment-images.tar.gz.sha256
docker load -i recruitment-images.tar.gz
docker image ls
```

Затем настройка deploy/secrets, новая БД/перенос, bootstrap и запуск по разделам выше. На сервере сборка не требуется: используйте --no-build --pull never. Если секреты созданы на сервере, пароли БД должны соответствовать именно этой новой установке, а не прежнему volume.
Для размера образов: docker image ls. Для размера файла: Get-Item recruitment-images.tar.gz (PowerShell) либо ls -lh (Linux). Размер ZIP исходников не равен размеру Docker-образов.

## 7. Доступ сотрудников и сопровождение

По умолчанию опубликован только 127.0.0.1:8765. Администратор настраивает корпоративный reverse proxy с HTTPS и SSO/VPN/ограничением доступа. Прокси не должен буферизовать MJPEG, timeout потока не менее 120 секунд. При HTTPS задайте SESSION_COOKIE_SECURE=true через окружение Compose или --env-file docker.env и пересоздайте web. Встроенного SSO/ролей сотрудников эта правка НЕ добавляет. Cookie-сессия не является корпоративным входом.
Не меняйте APP_BIND_IP на 0.0.0.0 без защищённого входа и firewall. Контейнеризация сама по себе не делает приложение безопасным для публикации.
Compose restart policy перезапускает завершившийся процесс, но статус unhealthy сам по себе НЕ вызывает перезапуск. Нужен внешний мониторинг health/ready, метрик, бэкапов и диска. Не добавляйте слепой restart всех сервисов при любом 503: это может оборвать рабочие задачи.

Остановка с сохранением данных:

```powershell
docker compose --profile maintenance stop web worker-general worker-browser backup
docker compose stop browser db
```

Останавливайте browser последним после drain workers. Не используйте down -v: это удаляет volumes с БД и токенами. На обновлении сохраняйте deploy, volumes, бэкап БД и hh.env; меняйте release tags, пересоздавайте сервисы в окно обслуживания. Откат кода после реальных внешних действий не отменяет отправленные письма и ИИ-запросы. Не восстанавливайте старый dump без анализа новых операций: это может снять дедупликацию.

## Источники технических решений

- https://playwright.dev/docs/docker : non-root, sandbox, init, shared memory, согласование версий.
- https://playwright.dev/docs/browsers#chromium-headless-shell : установка только headless shell.
- https://docs.docker.com/compose/how-tos/use-secrets/ : файловые secrets с доступом по сервисам.
- https://www.postgresql.org/download/linux/debian/ : PGDG для PostgreSQL client 16 на Debian bookworm.

Это ссылки на документацию, а не подтверждение испытаний данной сборки. Проверка безопасности, сканирование образов, реальные внешние интеграции и нагрузочная приёмка остаются на целевом сервере.
