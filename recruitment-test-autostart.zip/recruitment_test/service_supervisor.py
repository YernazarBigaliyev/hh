"""Single host supervisor: infrastructure startup, child backoff, drain and backups.
No schema migrations or administrator credentials are passed to web/workers.
"""
import argparse,os,signal,subprocess,sys,time,threading,logging
from pathlib import Path
ROOT=Path(__file__).resolve().parent
log=logging.getLogger(__name__)

def check_database():
    """PostgreSQL is an installed OS service. Do not start/stop a shared database."""
    import psycopg
    with psycopg.connect(os.environ['DATABASE_URL'],connect_timeout=5) as con:
        con.execute('SELECT next_run,last_error FROM task_jobs LIMIT 0')
        con.execute('SELECT 1 FROM worker_presence LIMIT 0')

def request_stop(child):
    if child.poll() is not None:return
    try:child.send_signal(signal.CTRL_BREAK_EVENT if os.name=='nt' else signal.SIGTERM)
    except (OSError,ProcessLookupError):pass

def kill_tree(child):
    import psutil
    try:
        proc=psutil.Process(child.pid)
        for item in proc.children(recursive=True):
            try:item.kill()
            except psutil.Error:pass
        proc.kill()
    except psutil.Error:pass

def acquire_lock():
    f=open(ROOT/'.supervisor.lock','a+b')
    if os.name=='nt':
        import msvcrt
        f.write(b'0');f.flush();f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
    else:
        import fcntl
        fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    return f

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--general',type=int,default=4);parser.add_argument('--browser',type=int,default=2)
    parser.add_argument('--external-browser',action='store_true');parser.add_argument('--no-backup',action='store_true')
    parser.add_argument('--stop',action='store_true');parser.add_argument('--drain-seconds',type=int,default=60)
    args=parser.parse_args()
    if args.stop:(ROOT/'.stop-server').touch();return
    if not 1<=args.general<=16 or not 1<=args.browser<=8:parser.error('Invalid worker count')
    lock=acquire_lock()
    (ROOT/'.stop-server').unlink(missing_ok=True)
    from dotenv import load_dotenv
    load_dotenv(ROOT/'.env.stage2')
    os.environ['PROCESS_ROLE']='supervisor'
    from logging_setup import configure_logging
    configure_logging()
    from process_limits import apply,release
    stop=threading.Event()
    for sig in [signal.SIGINT,signal.SIGTERM]+([signal.SIGBREAK] if os.name=='nt' else []):signal.signal(sig,lambda *_:stop.set())
    children=[];backup=None;backup_job=None;backup_next=0;log_cleanup_at=0
    check_database()
    specs=[('web',[sys.executable,'stage2_web.py'])]+[(lane,[sys.executable,'stage2_worker.py','--lane',lane]) for lane in ['general']*args.general+['browser']*args.browser]
    if not args.external_browser:specs.insert(0,('browser-service',[sys.executable,'native_browser.py']))
    def start(spec):
        role,cmd=spec;env=dict(os.environ,PROCESS_ROLE=role)
        # Infrastructure/admin variables never enter runtime children.
        for name in ('PG_ADMIN_URL','PG_BACKUP_URL','POSTGRES_PASSWORD','APP_DB_PASSWORD','BACKUP_DB_PASSWORD','NATIVE_PG_ADMIN_URL'):env.pop(name,None)
        child=subprocess.Popen(cmd,cwd=ROOT,env=env,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0)
        memory=int(os.getenv('BROWSER_SERVICE_MEMORY_MB','2048')) if role=='browser-service' else int(os.getenv('PROCESS_MEMORY_MB','768'))
        cpu=int(os.getenv('BROWSER_SERVICE_CPU_PERCENT','50')) if role=='browser-service' else int(os.getenv('PROCESS_CPU_PERCENT','20'))
        try:handle=apply(child,memory,cpu)
        except Exception:kill_tree(child);child.wait();raise
        return {'spec':spec,'child':child,'job':handle,'started':time.monotonic(),'failures':0,'next':0,'health_failures':0}
    try:
        for spec in specs:children.append(start(spec))
        while not stop.wait(2):
            if (ROOT/'.stop-server').exists():break
            now=time.monotonic()
            if now>=log_cleanup_at:
                import re,psutil
                for path in (ROOT/'logs').glob('*.jsonl*'):
                    match=re.fullmatch(r'.*-(\d+)\.jsonl(?:\.\d+)?',path.name)
                    if match and not psutil.pid_exists(int(match.group(1))) and path.stat().st_mtime<time.time()-int(os.getenv('LOG_KEEP_DAYS','7'))*86400:
                        path.unlink(missing_ok=True)
                log_cleanup_at=now+3600
            for item in children:
                child=item['child']
                if child.poll() is not None:
                    release(item['job']);item['job']=None
                    if not item['next']:
                        item['failures']=1 if now-item['started']>300 else item['failures']+1
                        item['next']=now+min(60,2**min(item['failures'],6))
                        log.warning('Process exited; restart delayed',extra={'stage':item['spec'][0]})
                    if now>=item['next']:
                        failures=item['failures'];new=start(item['spec']);item.update(new);item['failures']=failures
                    continue
                # Additional RSS watchdog (also usable on non-Windows test hosts).
                import psutil
                try:
                    rss=psutil.Process(child.pid).memory_info().rss
                    ceiling=int(os.getenv('BROWSER_SERVICE_MEMORY_MB','2048')) if item['spec'][0]=='browser-service' else int(os.getenv('PROCESS_MEMORY_MB','768'))
                    if rss>ceiling*1024*1024:
                        log.error('Process memory ceiling exceeded');kill_tree(child)
                except psutil.Error:pass
                if item['spec'][0]=='web' and now-item['started']>30:
                    import requests
                    try:
                        r=requests.get('http://127.0.0.1:'+os.getenv('APP_PORT','8765')+'/health/live',timeout=3)
                        item['health_failures']=0 if r.status_code==200 else item['health_failures']+1
                    except requests.RequestException:item['health_failures']+=1
                    if item['health_failures']>=3:log.error('Web liveness failed');request_stop(child)
            if not args.no_backup:
                if backup and backup.poll() is not None:
                    ok=backup.returncode==0;release(backup_job);backup_job=None;backup=None;backup_next=now+(int(os.getenv('BACKUP_INTERVAL_SECONDS','86400')) if ok else 300)
                if backup is None and now>=backup_next:
                    backup=subprocess.Popen([sys.executable,'backup_verify.py'],cwd=ROOT,
                        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0)
                    try:backup_job=apply(backup,int(os.getenv('PROCESS_MEMORY_MB','768')),int(os.getenv('PROCESS_CPU_PERCENT','20')))
                    except Exception:kill_tree(backup);backup.wait();raise
    finally:
        # Stop accepting requests, then stop claiming work; current jobs get a drain window.
        for item in children:
            if item['spec'][0]!='browser-service':request_stop(item['child'])
        if backup:request_stop(backup)
        deadline=time.monotonic()+max(5,args.drain_seconds)
        while time.monotonic()<deadline and (any(i['child'].poll() is None for i in children if i['spec'][0]!='browser-service') or (backup is not None and backup.poll() is None)):time.sleep(.2)
        # Browser service is stopped last so draining jobs keep their live pages.
        for item in children:
            if item['spec'][0]=='browser-service':
                request_stop(item['child'])
                try:item['child'].wait(timeout=15)
                except subprocess.TimeoutExpired:pass
            if item['child'].poll() is None:kill_tree(item['child'])
            item['child'].wait();release(item['job'])
        if backup and backup.poll() is None:kill_tree(backup);backup.wait()
        release(backup_job)
        # PostgreSQL is a separately managed OS service and is never stopped here.
        (ROOT/'.stop-server').unlink(missing_ok=True)
        lock.close()
if __name__=='__main__':main()
