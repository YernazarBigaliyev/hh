"""Native BrowserServer launcher. Uses runtime secret only, never administrator env."""
import os,sys,signal,threading,subprocess,shutil,time
from pathlib import Path
from urllib.parse import urlparse
from dotenv import load_dotenv

def terminate_tree(child):
    import psutil
    try:
        process=psutil.Process(child.pid)
        for item in process.children(recursive=True):
            try:item.kill()
            except psutil.Error:pass
        process.kill()
    except psutil.Error:pass

def main():
    root=Path(__file__).resolve().parent;load_dotenv(root/'.env.stage2')
    endpoint=urlparse(os.environ.get('BROWSER_WS_ENDPOINT',''))
    if endpoint.scheme!='ws' or endpoint.hostname!='127.0.0.1' or endpoint.port!=3000:
        raise SystemExit('Native browser requires ws://127.0.0.1:3000/<secret>. For an external service use --external-browser.')
    key=endpoint.path.strip('/')
    if len(key)<48 or any(c not in 'abcdef0123456789' for c in key):raise SystemExit('Invalid browser secret')
    node=shutil.which(os.getenv('NODE_BIN','node'))
    if not node:raise SystemExit('Install Node.js and add node.exe to PATH.')
    if not (root/'browser_service/node_modules/playwright/package.json').exists():
        raise SystemExit('Run npm install --prefix browser_service and npm run install-browser --prefix browser_service first.')
    env=dict(os.environ,BROWSER_WS_PATH=key)
    # Native launcher uses fixed loopback ports; standalone server.cjs is configurable.
    env.update(BROWSER_BIND_HOST='127.0.0.1',BROWSER_PORT='3000',BROWSER_HEALTH_PORT='3001')
    for name in ('PG_ADMIN_URL','PG_BACKUP_URL','POSTGRES_PASSWORD','APP_DB_PASSWORD','BACKUP_DB_PASSWORD','NATIVE_PG_ADMIN_URL'):env.pop(name,None)
    for name in list(env):
        if name.startswith(('GMAIL_','HH_','NANO_')) or name=='DATABASE_URL':env.pop(name,None)
    stop=threading.Event()
    for sig in [signal.SIGINT,signal.SIGTERM]+([signal.SIGBREAK] if os.name=='nt' else []):signal.signal(sig,lambda *_:stop.set())
    child=subprocess.Popen([node,str(root/'browser_service/server.cjs')],cwd=root/'browser_service',env=env,
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0)
    try:
        while child.poll() is None and not stop.wait(.25):pass
        if child.poll() is not None:return child.returncode
        import requests
        try:requests.post('http://127.0.0.1:3001/internal/shutdown',headers={'Authorization':'Bearer '+key},timeout=3)
        except requests.RequestException:pass
        try:return child.wait(timeout=10)
        except subprocess.TimeoutExpired:terminate_tree(child);child.wait();return 1
    finally:
        if child.poll() is None:terminate_tree(child);child.wait()
if __name__=='__main__':raise SystemExit(main())
