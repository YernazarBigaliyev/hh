const { chromium } = require('playwright');
const http = require('http');
const crypto = require('crypto');
(async () => {
  const path = process.env.BROWSER_WS_PATH;
  if (!path || !/^[a-f0-9]{48,128}$/.test(path)) throw new Error('Set BROWSER_WS_PATH');
  const server = await chromium.launchServer({headless:process.env.BROWSER_HEADLESS==='true',host:process.env.BROWSER_BIND_HOST||'127.0.0.1',port:Number(process.env.BROWSER_PORT||3000),wsPath:'/'+path,chromiumSandbox:true});
  let ready=false,stopping=false,failures=0,probing=false;
  const bounded=(promise,ms)=>Promise.race([promise,new Promise((_,reject)=>setTimeout(()=>reject(new Error('probe timeout')),ms))]);
  async function probe() {
    if(probing || stopping)return; probing=true; let client;
    try {
      client=await chromium.connect(server.wsEndpoint(),{timeout:5000});
      const context=await bounded(client.newContext(),5000);const page=await bounded(context.newPage(),5000);
      await page.goto('about:blank',{timeout:5000});await context.close();ready=true;failures=0;
    } catch { ready=false; failures++; }
    finally {if(client)await bounded(client.close(),2000).catch(()=>{});probing=false;}
    if(failures>=3 && !stopping)process.exit(1);
  }
  const health=http.createServer((req,res)=>{
    if(req.url=='/internal/shutdown' && req.method=='POST'){
      const supplied=Buffer.from(req.headers.authorization||'');
      const expected=Buffer.from('Bearer '+path);
      if(supplied.length!==expected.length || !crypto.timingSafeEqual(supplied,expected)){
        res.writeHead(403);return res.end();
      }
      res.writeHead(202);res.end();setImmediate(shutdown);return;
    }
    if(req.url!='/health/ready' && req.url!='/health/live'){res.writeHead(404);return res.end();}
    const ok=req.url=='/health/live' || (ready && !stopping);
    res.writeHead(ok?200:503,{'Content-Type':'application/json'});res.end(JSON.stringify({ready:ok}));
  });
  health.listen(Number(process.env.BROWSER_HEALTH_PORT||3001),process.env.BROWSER_BIND_HOST||'127.0.0.1');await probe();const timer=setInterval(probe,Math.max(1000,Number(process.env.BROWSER_PROBE_INTERVAL_MS||15000)));
  server.on('close',()=>{if(!stopping)process.exit(1);});
  async function shutdown(){if(stopping)return;stopping=true;ready=false;clearInterval(timer);health.close();await server.close();process.exit(0);}
  process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
  if(process.platform==='win32')process.on('SIGBREAK',shutdown);
  console.log('Browser service ready');
})().catch(()=>{console.error('Browser service startup failed');process.exit(1);});
