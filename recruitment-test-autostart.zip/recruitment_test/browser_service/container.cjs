'use strict';
const fs = require('fs');
process.env.BROWSER_WS_PATH = fs.readFileSync('/run/secrets/browser_key','utf8').trim();
require('./server.cjs');
