"""Offline SQLite -> empty PostgreSQL migration. Stop ALL old app processes first."""
import argparse,os,sqlite3,time,json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).resolve().parent/'.env.stage2')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--sqlite',required=True);args=parser.parse_args()
    source=Path(args.sqlite).resolve()
    if not source.is_file():raise SystemExit('Source SQLite file not found')
    if not os.getenv('DATABASE_URL'):raise SystemExit('DATABASE_URL is required')
    # Administrative migration is separate from the runtime DML-only account.
    load_dotenv(Path(__file__).resolve().parent/'.env.infrastructure')
    if os.getenv('PG_ADMIN_URL'):
        os.environ['DATABASE_URL']=os.environ['PG_ADMIN_URL']
        os.environ['APP_SCHEMA_MANAGED']='false'
    # Create the target schema, never alter the source.
    import app_state as state,operation_store as ops
    import durable_queue as queue,shared_screen
    queue.init();shared_screen.init()
    snapshot=sqlite3.connect(':memory:')
    with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as src:src.backup(snapshot)
    snapshot.row_factory=sqlite3.Row
    tables=['tasks','history','migrations','operations','resolution_audit','xray_history']
    existing={r[0] for r in snapshot.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    counts={}
    with queue.connect() as target:
        target.execute('SELECT pg_advisory_xact_lock(714202601)')
        for table in tables+['task_jobs','browser_screens']:
            if target.execute('SELECT 1 FROM '+table+' LIMIT 1').fetchone():raise RuntimeError('Target must be empty: '+table)
        for table in tables:
            if table not in existing:continue
            rows=snapshot.execute('SELECT * FROM '+table).fetchall();counts[table]=len(rows)
            for row in rows:
                columns=list(row.keys())
                target.execute('INSERT INTO '+table+' ('+','.join(columns)+') VALUES ('+','.join(['%s']*len(columns))+')',tuple(row))
        target.execute("SELECT setval(pg_get_serial_sequence('resolution_audit','id'),COALESCE((SELECT MAX(id) FROM resolution_audit),1),(SELECT COUNT(*)>0 FROM resolution_audit))")
        target.execute("UPDATE operations SET state='unknown',updated=%s WHERE state='sending'",(time.time(),))
        rows=target.execute("SELECT id,status,data FROM tasks WHERE status IN ('queued','running','interrupted','waiting_browser')").fetchall()
        for row in rows:
            task=json.loads(row['data']);tid=row['id']
            unknown=target.execute("SELECT 1 FROM operations WHERE task_id=%s AND state='unknown' LIMIT 1",(tid,)).fetchone()
            if unknown:task.update(status='waiting_manual',stage='manual_resolution',message='После миграции проверьте исход внешней операции.')
            elif row['status']=='waiting_browser':task.update(status='failed',stage='browser_interrupted',message='Старая браузерная сессия недоступна. Возобновите поиск.',finished=time.time())
            else:task.update(status='queued',message='Задача перенесена в PostgreSQL')
            target.execute('UPDATE tasks SET status=%s,data=%s,updated=%s WHERE id=%s',(task['status'],json.dumps(task,ensure_ascii=False),time.time(),tid))
    snapshot.close()
    queue.reconcile()
    print('Migration completed. Source unchanged. Counts:',counts)
if __name__=='__main__':main()
