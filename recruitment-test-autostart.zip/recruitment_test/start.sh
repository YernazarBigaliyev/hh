#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

trap 'echo "ERROR at line $LINENO. Startup stopped. Existing data was not deleted." >&2' ERR

command -v docker >/dev/null || {
    echo "Install Docker Engine and Docker Compose first."
    exit 1
}
docker compose version
docker info >/dev/null || {
    echo "Docker is unavailable. Check daemon status and user permissions."
    exit 1
}

for name in db_admin db_app db_backup browser_key metrics_token gmail_password hh_seed; do
    test -s "deploy/secrets/$name" || {
        echo "Missing or empty secret: deploy/secrets/$name"
        exit 1
    }
done

chmod 700 deploy deploy/secrets
chmod 444 deploy/secrets/{db_admin,db_app,db_backup,browser_key,metrics_token,gmail_password,hh_seed}

echo "[1/6] Checking configuration..."
docker compose --profile admin config --quiet

echo "[2/6] Downloading PostgreSQL..."
docker compose pull db

echo "[3/6] Building application and browser..."
docker compose build web browser

echo "[4/6] Starting database..."
docker compose up -d --wait --wait-timeout 180 --no-build --pull never db

echo "[5/6] Initializing database..."
docker compose --profile admin run --rm --no-deps --pull never bootstrap

echo "[6/6] Starting application..."
docker compose up -d --wait --wait-timeout 240 --no-build --pull never \
    --scale worker-general="${GENERAL_WORKERS:-2}" \
    --scale worker-browser="${BROWSER_WORKERS:-1}"

docker compose run --rm --no-deps --pull never web smoke-browser
docker compose run --rm --no-deps --pull never web check-gmail

docker compose exec -T web python -c \
'import json,urllib.request; d=json.load(urllib.request.urlopen("http://127.0.0.1:8765/health/ready",timeout=15)); print(json.dumps(d,indent=2)); raise SystemExit(0 if d.get("ready") is True else 1)'

docker compose ps -a
echo "SUCCESS: startup and checks completed."
echo "Access: use the host and port configured in .env."
echo "Default access is local to the server: http://127.0.0.1:8765"
echo "External access requires a protected reverse proxy or SSH tunnel."
