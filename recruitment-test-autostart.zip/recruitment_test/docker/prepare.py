"""Host-side setup, standard library only. No database or Docker actions."""
import argparse,getpass,secrets,shutil,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source-env',required=True);args=p.parse_args()
root=Path(__file__).resolve().parents[1];target=root/'deploy'
source=Path(args.source_env).resolve()
if not source.is_file():raise SystemExit('Source .env not found')
if target.exists():raise SystemExit('deploy already exists; no credentials overwritten')
password=''.join(getpass.getpass('Gmail app password (16 characters): ').split())
if len(password)!=16 or not password.isascii() or not password.isalnum():raise SystemExit('Invalid Gmail app password')
target.mkdir(mode=0o700);folder=target/'secrets';folder.mkdir(mode=0o700)
values={name:secrets.token_hex(32) for name in ['db_admin','db_app','db_backup','browser_key','metrics_token']}
values['gmail_password']=password
for name,value in values.items():
    path=folder/name;path.write_text(value+'\n',encoding='utf-8');path.chmod(0o444)
shutil.copyfile(source,folder/'hh_seed');(folder/'hh_seed').chmod(0o600)
(target/'backups').mkdir(mode=0o700)
print('Created deploy/secrets. Protect Windows ACLs or Linux permissions. Do not share deploy.')
