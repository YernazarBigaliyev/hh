"""Export already built images as gzip without PowerShell binary redirection."""
import gzip,subprocess,shutil,hashlib
from pathlib import Path
images=['recruitment-app:docker1','recruitment-browser:pw1.58.0','recruitment-maintenance:docker1','postgres:16-bookworm']
root=Path(__file__).resolve().parents[1]
target=root/'recruitment-images.tar.gz';temp=target.with_suffix('.gz.partial')
if target.exists() or temp.exists():raise SystemExit('Export exists; choose a new release directory')
for image in images:subprocess.run(['docker','image','inspect',image],stdout=subprocess.DEVNULL,check=True)
child=subprocess.Popen(['docker','save',*images],stdout=subprocess.PIPE)
try:
    with gzip.open(temp,'wb',compresslevel=6) as out:shutil.copyfileobj(child.stdout,out)
    child.stdout.close()
    if child.wait()!=0:raise RuntimeError('docker save failed')
    temp.replace(target)
    with target.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    target.with_suffix('.gz.sha256').write_text(digest+'  '+target.name+'\n',encoding='ascii')
    print('EXPORTED',target.name,'bytes=',target.stat().st_size,'sha256=',digest)
finally:
    if child.poll() is None:child.terminate();child.wait()
    temp.unlink(missing_ok=True)
