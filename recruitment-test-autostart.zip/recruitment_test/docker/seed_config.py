"""One-shot root init for a dedicated config volume; never overwrites refreshed tokens."""
import os
from pathlib import Path
from dotenv import dotenv_values,set_key
folder=Path('/config');folder.mkdir(exist_ok=True)
path=folder/'hh.env'
if not path.exists():
    values=dotenv_values('/run/secrets/hh_seed',interpolate=False)
    allowed={'EMPLOYER_ID','API_NANO_URL','MODEL_NANO','NANO_GPT_API_KEY','NANO_TIMEOUT',
        'RESUMES_TO_FIND','MAX_BACKGROUND_WORKERS','TASK_RETENTION_HOURS','RESERVATION_STALE_MINUTES',
        'GMAIL_USER','GMAIL_SMTP_PORT','GMAIL_TIMEOUT_SECONDS'}
    path.touch(mode=0o600)
    for name,value in values.items():
        if value is not None and (name in allowed or name.startswith(('HH_','RESUME_'))):
            set_key(str(path),name,value)
    set_key(str(path),'HH_INTERACTIVE_AUTH','false')
os.chown(folder,10001,10001);folder.chmod(0o700)
os.chown(path,10001,10001);path.chmod(0o600)
print('CONFIG_VOLUME_READY (existing tokens preserved)')
