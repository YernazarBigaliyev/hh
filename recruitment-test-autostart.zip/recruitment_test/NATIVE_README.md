# Историческая инструкция нативной установки

Текущая версия использует Gmail без COM. Читайте GMAIL_README.md.
Ниже сохранена инструкция исходной сборки; требования Outlook больше не действуют.

# Проект без Docker: запуск на Windows

Эта сборка не использует Docker, Compose, контейнеры или виртуальный дисплей.
PostgreSQL устанавливается как обычная служба Windows. Браузерный сервис
запускается через Node.js и Playwright, приложение и обработчики — через Python.
Сохранены очередь, PostgreSQL, ASGI, логи, повторы, роли БД, бэкапы и метрики.
HH API, промпты/оценивание, Outlook, UI и LinkedIn-only поиск не менялись.

## Что установить

1. Python 3.12 (команды py и python).
2. Node.js 22 или 24 с npm. В package.json минимальная версия Node.js — 20.
3. PostgreSQL 16 для Windows, включая сервер, pg_dump и pg_restore.
   При установке запомните пароль администратора postgres и порт (обычно 5432).
4. Классический Outlook с настроенной учётной записью, как в прежней версии.

Служба PostgreSQL должна работать и иметь автоматический запуск в Windows.
Проверьте её в services.msc. Приложение проверяет подключение, но намеренно
не запускает и не останавливает общую службу БД и не меняет её пароль.
Node.js и Python должны быть доступны пользователю, под которым запускается проект.
Серверный установщик PostgreSQL и браузерные бинарники в ZIP не включены.

## 1. Подготовка папки

Распакуйте архив, например в C:\Projects\hh_recruitment_project_final.
Перенесите свой прежний .env с настройками HH/ИИ/Outlook. Секретов в ZIP нет.
В PowerShell из папки проекта:

```powershell
cd C:\Projects\hh_recruitment_project_final
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-server.txt
npm.cmd install --prefix browser_service
npm.cmd run install-browser --prefix browser_service
```

Или выполните .\ops\install_native.ps1. Этот скрипт устанавливает Python/Node
зависимости и Chromium, но не устанавливает сервер PostgreSQL.
При установке зависимостей нужен доступ в интернет. Версии Python и Node
Playwright согласованы: 1.58.0. Не обновляйте одну сторону отдельно.

## 2. Настройка PostgreSQL

Убедитесь, что служба PostgreSQL уже запущена:

```powershell
.\.venv\Scripts\python.exe stage2_setup.py
```

Введите адрес, порт, имя отдельной БД (по умолчанию recruitment), имя
администратора (postgres) и ЕГО ДЕЙСТВУЮЩИЙ пароль. Пароль вводится скрыто.
Скрипт не придумывает пароль установленного PostgreSQL и не меняет его.
Он создаёт:
- .env.stage2 — runtime-подключение recruitment_app, настройки и токен метрик;
- .env.infrastructure — административное подключение и read-only backup account.

Существующие файлы не перезаписываются. Защитите оба файла Windows ACL,
не публикуйте их и не включайте в архивы.

Затем создайте БД и схему:

```powershell
.\.venv\Scripts\python.exe native_bootstrap.py --create-db
```

Команда создаёт отдельную БД, только если её ещё нет, и запускает bootstrap
ролей/схемы. Для существующей БД можно выполнить native_bootstrap.py без
--create-db. Базы postgres/template0/template1 как рабочие запрещены.
Роль приложения имеет DML, но не CREATE/DROP/ALTER и не SUPERUSER.
Роль резервного копирования имеет SELECT. DDL выполняется администратором.

Если нужно перенести свою действующую SQLite-базу, до старта обработчиков:

```powershell
.\.venv\Scripts\python.exe migrate_stage2.py --sqlite 'C:\PATH\TO\recruitment.db'
```

Укажите именно свою базу, а не пример из ZIP. Целевая БД должна быть пустой.
Исходный SQLite-файл не меняется. Живые CAPTCHA не переносятся.

## Если уже работала предыдущая серверная версия

Остановите прежнее приложение и сделайте проверенную резервную копию БД.
Данные старого PostgreSQL не копируются в новый установленный сервер сами собой.
Не удаляйте старое хранилище до проверки переноса. У старого и нового серверов
не должно быть конфликта портов: при необходимости выберите 5433 для нового.

Если продолжаете использовать ту же доступную БД, сохраните существующие
.env.stage2 и .env.infrastructure, проверьте их адрес/порт и выполните:

```powershell
.\.venv\Scripts\python.exe native_bootstrap.py
```

Если переносите данные на новый PostgreSQL, восстановите проверенный dump
через pgAdmin/pg_restore в НОВУЮ ПУСТУЮ выделенную БД, без старых владельцев
и привилегий (--no-owner --no-privileges). Затем укажите её в .env.infrastructure
и .env.stage2 и выполните native_bootstrap.py для ролей/обновления схемы.
Не восстанавливайте dump поверх действующей рабочей базы и не удаляйте её
таблицы ради устранения ошибок импорта.

Браузер запускается на том же Windows-хосте. В .env.stage2 должны быть:

```dotenv
BROWSER_WS_ENDPOINT=ws://127.0.0.1:3000/СУЩЕСТВУЮЩИЙ_СЕКРЕТНЫЙ_ПУТЬ
BROWSER_HEALTH_URL=http://127.0.0.1:3001/health/ready
APP_SCHEMA_MANAGED=true
```

stage2_setup.py создаёт правильные значения при новой установке.
Для старой конфигурации без разделения runtime/admin ролей есть
upgrade_stage2_config.py; сначала сохраните резервные копии и проверьте адреса.

## 3. Проверка бэкапов

Если pg_dump/pg_restore не в PATH, добавьте в .env.infrastructure:

```dotenv
PG_DUMP_BIN='C:\Program Files\PostgreSQL\16\bin\pg_dump.exe'
PG_RESTORE_BIN='C:\Program Files\PostgreSQL\16\bin\pg_restore.exe'
```

```powershell
.\.venv\Scripts\python.exe backup_verify.py
```

Ожидается BACKUP_RESTORE_VERIFIED. Создаётся согласованный dump, он реально
восстанавливается во временную БД, сравниваются таблицы и число строк.
Рабочая БД не перезаписывается. В backups/ сохраняются dump и JSON с SHA-256.
Supervisor повторяет проверку ежедневно; при ошибке — через 5 минут.
Копируйте бэкапы также на отдельное защищённое хранилище.

## 4. Запуск всего проекта

```powershell
.\.venv\Scripts\python.exe service_supervisor.py --general 4 --browser 2
```

Команда проверяет установленную БД, запускает native_browser.py, web и workers.
Терминал оставьте открытым. Для проверки браузера откройте второй терминал:

```powershell
.\.venv\Scripts\python.exe tests_server\smoke_browser.py
```

Ожидается REMOTE_BROWSER_ISOLATION_OK. Если проверка не проходит, не начинайте
рабочие поиски. При первом запуске Chromium может потребовать разрешения ОС.

Приложение: http://localhost:8765
Проверка процесса: http://localhost:8765/health/live
Готовность зависимостей: http://localhost:8765/health/ready
Готовность браузера: http://127.0.0.1:3001/health/ready

Готовность web — 200 только при доступной схеме БД, браузере и свежих heartbeat
обоих типов workers; иначе 503. Проверка не подтверждает доступность HH/ИИ/Outlook.
Браузерные порты 3000/3001 привязаны только к 127.0.0.1. Не публикуйте их наружу.

Если браузерный сервис уже управляется отдельно, есть --external-browser:
в этом режиме supervisor не запускает и не останавливает его.
Для отключения встроенного расписания бэкапов есть --no-backup.

## 5. Корректная остановка

Из второго терминала в той же папке:

```powershell
.\.venv\Scripts\python.exe service_supervisor.py --stop
```

Web прекращает приём запросов, workers — захват новых задач. Текущим задачам
даётся 60 секунд (--drain-seconds), затем оставшиеся процессы завершаются.
Браузерный сервис останавливается последним, после drain. PostgreSQL продолжает
работать как служба Windows: это не ошибка и не потеря данных.
После уничтожения браузера старую CAPTCHA нельзя восстановить; сохранённые
ссылки остаются. Неизвестный исход внешней операции требует ручной проверки.

## 6. Автозапуск

```powershell
.\ops\install_autostart.ps1 -Python 'C:\Projects\hh_recruitment_project_final\.venv\Scripts\python.exe'
```

Автозапуск при входе пользователя, у которого настроен Outlook. PostgreSQL
должен запускаться своей службой автоматически. Запуск до входа пользователя
не заявляется, поскольку Outlook оставлен без изменений.
Удаление задания: Unregister-ScheduledTask -TaskName RecruitmentServer -Confirm:$false.

## Сохранённые инфраструктурные функции

- FastAPI/Uvicorn, ограничения тела запросов и параллельности, поток экрана.
- PostgreSQL-очередь, lease, выделенное соединение блокировки задачи.
- Пулы соединений, ограниченные повторы временных ошибок, backoff и jitter.
- Неизвестный результат ИИ/почты не повторяется автоматически.
- Отдельные JSON-логи процессов и ротация.
- /metrics с Authorization: Bearer <METRICS_TOKEN>, примеры Prometheus в ops/.
- Метрики очереди, ожидания CAPTCHA, ошибок, повторов, зависаний и бэкапов.
- Windows Job Object лимиты CPU/RAM и перезапуск упавших процессов.

Настройки .env.stage2:

```dotenv
DB_POOL_MAX=6
JOB_MAX_ATTEMPTS=3
JOB_RETRY_BASE_SECONDS=5
JOB_RETRY_MAX_SECONDS=300
BROWSER_MAX_SESSIONS=2
CAPTCHA_WAIT_SECONDS=1800
PROCESS_MEMORY_MB=768
PROCESS_CPU_PERCENT=20
BROWSER_SERVICE_MEMORY_MB=2048
BROWSER_SERVICE_CPU_PERCENT=50
```

Лимит браузерного сервиса распространяется на его дерево процессов на Windows.
Контейнерных лимитов/изоляции здесь нет. PostgreSQL управляется средствами
установленного сервера и ОС; его ресурсы supervisor не ограничивает.
Рабочие обработчики остаются Windows-only из-за прежней Outlook-интеграции.
HTTPS и корпоративный вход не добавлялись: используйте внутреннюю сеть/VPN.

## Проверки и границы

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests
$env:STAGE2_TEST_DATABASE_URL='postgresql://ADMIN:PASSWORD@HOST:5432/DEDICATED_TEST_DB'
.\.venv\Scripts\python.exe -m unittest discover -s tests_server -v
.\.venv\Scripts\python.exe -m unittest discover -s tests_hardening -v
.\.venv\Scripts\python.exe -m unittest discover -s tests_native -v
```

Только выделенный тестовый кластер: тесты меняют пароли тестовых ролей,
создают/удаляют временные БД, запускают и останавливают процессы.
Не направляйте тесты на рабочую БД. Для проверки восстановления задайте также
PG_DUMP_BIN и PG_RESTORE_BIN. Фактические результаты: NATIVE_TEST_REPORT.txt.

Перед рабочим запуском на Windows обязательно проверить реальный Chromium,
параллельные CAPTCHA, Outlook, Job Object, автозапуск и резервную копию.
