# Recruitment Assistant: Gmail, без COM, подготовка к контейнеризации

Основа: приложенный hh_recruitment_project_no_docker.zip. Это полный проект, а не патч.
Dockerfile, Compose, образы и команды Docker намеренно НЕ добавлены.

## Что изменено
- HH-письма и X-Ray дайджесты отправляются через Gmail SMTP, а не Outlook.
- Удалены COM-вызовы, pywin32 и запрет Linux в stage2_worker.py.
- Сохранены HTML-шаблоны, поиск, промпты, очередь, журнал операций, история и схема БД.
- TLS с проверкой сертификата: 465 implicit TLS или 587 с обязательным STARTTLS.
- Один отправитель: GMAIL_USER. Подмена From и несколько получателей одной строкой запрещены.
- Пароль можно передать переменной окружения или файлом секрета.
- Добавлена проверка авторизации без отправки письма: check_gmail.py.
- Добавлены настраиваемые адрес/порты BrowserServer и headless-режим.
- Серверные точки входа читают окружение с приоритетом над файлами.
- Первичный интерактивный вход HH по умолчанию отключён. Refresh существующего токена сохранён.

## Важно до обновления
Сначала завершите задачи, особенно письма с неизвестным исходом. Сделайте проверенную
резервную копию PostgreSQL. Остановите старый supervisor. Распакуйте проект ОТДЕЛЬНО.
Не удаляйте рабочую БД и не запускайте старые и новые обработчики одновременно.
Переход на Gmail не разрешает автоматически повторить старые письма Outlook.
Проверьте такие операции в прежнем почтовом ящике и разрешите вручную в старом интерфейсе.

Рабочая SQLite-база, логи, секреты и lock-файлы исходного архива исключены из выдачи.
Ваша рабочая PostgreSQL остаётся на месте. Для неё миграция схемы этой правкой не требуется.
Если вы использовали SQLite, сохраняйте свою БД отдельно; не создавайте новую пустую историю.

## Настройка Gmail
Включите двухэтапную проверку и создайте отдельный пароль приложения для проекта,
если аккаунт это разрешает. Обычный пароль Google не подходит. OAuth в этой версии
не реализован. Если пароль приложения недоступен по политике организации,
не отключайте защиту: требуется другая интеграция с участием администратора.

Справка Google:
https://support.google.com/accounts/answer/185833
https://knowledge.workspace.google.com/admin/gmail/send-email-from-a-printer-scanner-or-app

Перенесите свои .env, .env.stage2 и .env.infrastructure из остановленной рабочей версии.
Не публикуйте их. Добавьте в .env (не в PowerShell) новые строки:

```dotenv
GMAIL_USER=your-account@gmail.com
GMAIL_APP_PASSWORD=YOUR_16_CHARACTER_APP_PASSWORD
GMAIL_SMTP_PORT=465
GMAIL_TIMEOUT_SECONDS=30
HH_INTERACTIVE_AUTH=false
```

Старые OUTLOOK_MODE и OUTLOOK_RECIPIENT больше не используются. Режима Display/черновика
нет: успешная задача действительно отправляет письмо. Получатель по-прежнему задаётся
в форме проекта. Для первого теста используйте свой адрес и неконфиденциальные данные.

Альтернатива паролю в .env:

```dotenv
GMAIL_USER=your-account@gmail.com
GMAIL_APP_PASSWORD_FILE=/run/secrets/gmail_app_password
GMAIL_SMTP_PORT=465
```

Не задавайте GMAIL_APP_PASSWORD и GMAIL_APP_PASSWORD_FILE одновременно.
Файл секрета содержит только пароль; ограничьте доступ владельцем процесса.
Не передавайте корпоративные резюме в личную почту без согласования в организации.

## Обновление на вашем Windows-компьютере
Все команды выполняются в НОВОЙ папке проекта. Перенесите конфигурацию, не копируйте
старую .venv. Не повторяйте stage2_setup.py для уже настроенной базы.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-server.txt
npm.cmd install --prefix browser_service
npm.cmd run install-browser --prefix browser_service
.\.venv\Scripts\python.exe check_gmail.py
```

Ожидается GMAIL_AUTH_OK (no email sent). Проверка не отправляет письма и не гарантирует
доставку будущего письма. Если она не прошла, рабочие задачи не запускайте.

В ранее использованном Node.js 24.16.0 установка Chromium зависала. При повторении
используйте уже проверенную у вас команду установки через временный Node.js 24.15.0:

```powershell
npm.cmd exec --yes --package=node@24.15.0 -- node .\browser_service\node_modules\playwright\cli.js install chromium
```

Запуск и остановка:

```powershell
.\.venv\Scripts\python.exe service_supervisor.py --general 4 --browser 2
```

Во втором терминале:

```powershell
.\.venv\Scripts\python.exe tests_server\smoke_browser.py
Invoke-RestMethod "http://127.0.0.1:8765/health/ready"
```

Откройте http://localhost:8765. Сначала одна тестовая задача на свой адрес.
Не увеличивайте параллельность до проверки лимитов Gmail и нагрузки.

```powershell
.\.venv\Scripts\python.exe service_supervisor.py --stop
```

## Подготовка к будущему Docker/Linux
Код больше не требует Outlook/COM. Раздельные процессы для будущих сервисов:

```bash
python stage2_web.py
python stage2_worker.py --lane general
python stage2_worker.py --lane browser
node browser_service/server.cjs
```

Это четыре РАЗНЫХ процесса, не последовательный сценарий в одном терминале.
Для нескольких workers каждый процесс запускается отдельно. Supervisor остаётся
вспомогательным вариантом для одного хоста, а не будущим контейнерным entrypoint.

Зависимости Python: requirements-server.txt. Node Playwright и Python Playwright
должны совпадать: 1.58.0. Chromium и системные Linux-библиотеки устанавливаются
при подготовке окружения, не при обработке задач.

Для standalone BrowserServer без графического дисплея:

```dotenv
BROWSER_HEADLESS=true
BROWSER_BIND_HOST=127.0.0.1
BROWSER_PORT=3000
BROWSER_HEALTH_PORT=3001
BROWSER_WS_PATH=REPLACE_WITH_64_HEX_CHARACTERS
```

Нативный native_browser.py намеренно сохраняет loopback и порты 3000/3001.
Для отдельных контейнеров позднее запускайте server.cjs напрямую: bind 0.0.0.0
только во внутренней защищённой сети, без публикации 3000/3001 наружу.
Задайте BROWSER_WS_ENDPOINT и BROWSER_HEALTH_URL в окружении web/workers,
используя внутреннее имя браузерного сервиса, а не localhost.
Секретный путь WebSocket не является заменой сетевой изоляции.

Headless не гарантирует прохождение Google CAPTCHA. Существующий ручной экран
сохраняется, автоматическое решение и обход защиты не добавлены. Для headed-режима
Linux нужен дисплей/виртуальный дисплей, здесь он не устанавливается.

Настройки приложения для будущего развёртывания:
- DATABASE_URL: доступная PostgreSQL, отдельная runtime-роль без DDL.
- TASK_QUEUE_BACKEND=postgres, APP_SCHEMA_MANAGED=true.
- APP_HOST=0.0.0.0 только за защищённым входом; локально можно 127.0.0.1.
- APP_RUNTIME_ENV_FILE: необязательный путь runtime-файла вместо .env.stage2;
  пустое значение отключает чтение runtime-файла.
- APP_ENV_FILE: путь файла HH/ИИ/Gmail вместо .env. Каталог должен быть доступен
  для атомарного обновления HH-токенов. Не монтируйте один read-only файл для refresh.
- LOG_TO_FILE=false для stdout; LOG_DIR задайте доступным для записи каталогом.
- GMAIL_APP_PASSWORD_FILE для секрета, METRICS_TOKEN для метрик.
- Административные реквизиты не передавайте web/workers/browser.
- Bootstrap выполняйте отдельной административной операцией, не на каждом старте.
- Резервное копирование запускайте отдельным заданием с pg_dump/pg_restore,
  доступным хранилищем и отдельными реквизитами.
- Для нескольких процессов HH нужна общая локальная writable-папка токенов/lock.
  Разные хосты и сетевые ФС не покрыты текущей блокировкой: кластер не заявляется.
- Сигналы SIGTERM обрабатываются, но оркестратор должен дать время на drain.

## Семантика отправки
Sent означает, что SMTP принял письмо, не доказательство доставки адресату.
Таймаут/разрыв при отправке оставляет неизвестный исход и требует ручной проверки.
Автоматического SMTP-повтора нет. Ошибка QUIT после подтверждённого приёма не
превращает письмо в неуспешное и не провоцирует повтор. Консервативная логика workflow
может потребовать ручного решения даже при ошибке настройки до отправки.
Exactly-once и автоматическая сверка папки Gmail «Отправленные» не реализованы.
Проверка /health/ready по-прежнему проверяет БД/браузер/workers, не Gmail/HH/ИИ.

## Границы готовности
Подготовлен код для будущей контейнеризации, но Docker-развёртывание НЕ выполнено
и НЕ проверено. Dockerfile/Compose, ресурсы контейнеров, non-root/sandbox/seccomp,
shared memory, volumes, HTTPS/SSO, сетевые политики и нагрузочная приёмка остаются
отдельным этапом. Не публикуйте интерфейс напрямую в интернет.
Права на задачи по cookie не являются корпоративной авторизацией.
Windows Job Object не действует в Linux: лимиты нужно будет задать средствами ОС/контейнеров.

## Тесты

```bash
python -m unittest discover -s tests_gmail -v
python -m unittest discover -s tests
python -m unittest discover -s tests_native
python -m unittest discover -s tests_hardening
```

Реальные интеграционные PostgreSQL-тесты требуют отдельного тестового кластера,
не рабочей БД. Фактические результаты текущей сборки: GMAIL_TEST_REPORT.txt.
Старые отчёты отражают предыдущие сборки, не текущую приёмку.
