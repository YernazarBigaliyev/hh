from app_state import APP_STATE
from hh_client import SESSION,ensure_token
from logging_setup import configure_logging
from settings import HH_USER_AGENT,validate_hh_settings
from web_server import load_vacancies,start_server

def main():
    configure_logging();print('[STARTUP] Проверка настроек...',flush=True);missing=validate_hh_settings()
    if missing:APP_STATE['startup_error']='Не заполнены настройки HH: '+', '.join(missing);print('[STARTUP] '+APP_STATE['startup_error'],flush=True)
    else:
        print('[STARTUP] Проверка авторизации HH...',flush=True);token=ensure_token()
        if not token:APP_STATE['startup_error']='Не удалось авторизоваться в HH.';print('[STARTUP] '+APP_STATE['startup_error'],flush=True)
        else:SESSION.headers.update({'Authorization':f'Bearer {token}','User-Agent':HH_USER_AGENT});print('[STARTUP] Авторизация HH готова',flush=True);load_vacancies()
    start_server()
if __name__=='__main__':main()