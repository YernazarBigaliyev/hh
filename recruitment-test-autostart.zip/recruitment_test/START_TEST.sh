#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then echo 'Docker Engine required'; exit 1; fi
docker compose version >/dev/null
if [ "$(uname -m)" != x86_64 ]; then echo 'This bundle requires Linux x86-64'; exit 1; fi
if [ "${CONFIRM_TEST_ACCOUNTS:-}" != YES ]; then
  echo 'Ensure the laptop is stopped OR independent HH credentials are configured.'
  echo 'This stand sends real Gmail messages and can incur AI charges.'
  echo 'Then run: CONFIRM_TEST_ACCOUNTS=YES sh START_TEST.sh'
  exit 1
fi
chmod 700 deploy deploy/secrets
chmod 444 deploy/secrets/db_admin deploy/secrets/db_app deploy/secrets/db_backup deploy/secrets/browser_key deploy/secrets/metrics_token deploy/secrets/gmail_password
chmod 600 deploy/secrets/hh_seed
sha256sum -c recruitment-images.tar.gz.sha256
docker load -i recruitment-images.tar.gz
docker compose --profile admin --profile maintenance config --quiet
# Do not bootstrap an existing stand or alter its passwords.
existing=$(docker volume ls --filter label=com.docker.compose.project=recruitment-test --format '{{.Name}}')
if [ -n "$existing" ]; then
  echo 'Existing recruitment-test volumes detected. Stop: use the update/restart procedure, not first-install.'
  exit 1
fi
docker compose up -d --no-build --pull never db
ready=0
for n in $(seq 1 60); do
  if docker compose exec -T db pg_isready -U postgres -d recruitment >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || { docker compose logs --tail 40 db; exit 1; }
docker compose --profile admin run --rm --no-deps --pull never bootstrap
docker compose up -d --no-build --pull never init-config browser
ready=0
for n in $(seq 1 60); do
  if docker compose exec -T browser node -e "fetch('http://127.0.0.1:3001/health/ready').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))" >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || { docker compose logs --tail 60 browser init-config; exit 1; }
docker compose run --rm --no-deps --pull never web smoke-browser
docker compose run --rm --no-deps --pull never web check-gmail
docker compose up -d --no-build --pull never --scale worker-general=16 --scale worker-browser=8
docker compose --profile maintenance up -d --no-build --pull never init-backups backup
ready=0
for n in $(seq 1 60); do
  if docker compose exec -T web python docker/healthcheck.py >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || { docker compose logs --tail 60 web worker-general worker-browser; exit 1; }
echo 'TEST_STAND_READY: http://127.0.0.1:8765 on server; configure protected proxy or SSH tunnel.'
echo 'Verify backup logs: docker compose --profile maintenance logs --tail 40 backup'
