# Recruitment Assistant: Docker-комплект

Начните с **DOCKER_README.md**. В комплекте Dockerfile, Compose, отдельный браузерный образ и экспорт образов для передачи администратору.
Основа: hh_recruitment_project_three_fixes.zip. Бизнес-логика и последние исправления сохранены.
Контейнерная сборка/запуск здесь не выполнялись. Текущие проверки: DOCKER_TEST_REPORT.txt.
Исторические GMAIL/NATIVE/THREE_FIXES отчёты сохранены, но не являются инструкцией Docker-развёртывания.
