"""Build a private handoff ZIP locally. No DB writes, no container restarts.
Run with Python 3.12 from the current Docker project directory.
The resulting ZIP CONTAINS CREDENTIALS: transfer only over an approved private channel.
"""
import argparse,hashlib,os,re,secrets,subprocess,tempfile,zipfile
from pathlib import Path

START = r'''#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then echo 'Docker Engine required'; exit 1; fi
docker compose version >/dev/null
if [ "$(uname -m)" != x86_64 ]; then echo 'This bundle requires Linux x86-64'; exit 1; fi
if [ "${CONFIRM_TEST_ACCOUNTS:-}" != YES ]; then
  echo 'Ensure the laptop is stopped OR independent HH credentials are configured.'
  echo 'This stand sends real Gmail messages and can incur AI charges.'
  echo 'Then run: CONFIRM_TEST_ACCOUNTS=YES sh START_TEST.sh'
  exit 1
fi
chmod 700 deploy deploy/secrets
chmod 444 deploy/secrets/db_admin deploy/secrets/db_app deploy/secrets/db_backup deploy/secrets/browser_key deploy/secrets/metrics_token deploy/secrets/gmail_password
chmod 600 deploy/secrets/hh_seed
sha256sum -c recruitment-images.tar.gz.sha256
docker load -i recruitment-images.tar.gz
docker compose --profile admin --profile maintenance config --quiet
# Do not bootstrap an existing stand or alter its passwords.
existing=$(docker volume ls --filter label=com.docker.compose.project=recruitment-test --format '{{.Name}}')
if [ -n "$existing" ]; then
  echo 'Existing recruitment-test volumes detected. Stop: use the update/restart procedure, not first-install.'
  exit 1
fi
docker compose up -d --no-build --pull never db
ready=0
for n in $(seq 1 60); do
  if docker compose exec -T db pg_isready -U postgres -d recruitment >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || { docker compose logs --tail 40 db; exit 1; }
docker compose --profile admin run --rm --no-deps --pull never bootstrap
docker compose up -d --no-build --pull never init-config browser
ready=0
for n in $(seq 1 60); do
  if docker compose exec -T browser node -e "fetch('http://127.0.0.1:3001/health/ready').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))" >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || { docker compose logs --tail 60 browser init-config; exit 1; }
docker compose run --rm --no-deps --pull never web smoke-browser
docker compose run --rm --no-deps --pull never web check-gmail
docker compose up -d --no-build --pull never --scale worker-general=16 --scale worker-browser=8
docker compose --profile maintenance up -d --no-build --pull never init-backups backup
ready=0
for n in $(seq 1 60); do
  if docker compose exec -T web python docker/healthcheck.py >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
[ "$ready" = 1 ] || { docker compose logs --tail 60 web worker-general worker-browser; exit 1; }
echo 'TEST_STAND_READY: http://127.0.0.1:8765 on server; configure protected proxy or SSH tunnel.'
echo 'Verify backup logs: docker compose --profile maintenance logs --tail 40 backup'
'''

README = """PRIVATE TEST HANDOFF. CONTAINS CREDENTIALS. DO NOT PUBLISH.
Linux x86-64, Docker Engine + Compose required. No rebuild required.
New isolated recruitment-test volumes; NO working DB/history is included.
16 general + 8 browser, BROWSER_MAX_SESSIONS=8; capacity is not load-tested.

First install:
  CONFIRM_TEST_ACCOUNTS=YES sh START_TEST.sh

Only confirm after stopping the laptop stand OR supplying independent HH credentials.
HH refresh tokens must not be shared between simultaneously running hosts.
The copied Gmail/AI accounts are real: mail sends and API charges are real.
A new empty DB has no old deduplication history. Use synthetic/test candidates,
separate HH/AI/Gmail accounts and your own recipient addresses where possible.
This package does not restrict recipient addresses or disable real sending.

Web is bound to server loopback. Use a protected HTTPS/SSO proxy or SSH tunnel:
  ssh -L 8766:127.0.0.1:8765 USER@SERVER
Then open http://localhost:8766 on the client. Do not expose port 8765 publicly.
No built-in corporate authentication was added.

START_TEST.sh is first-install only. If volumes exist it refuses bootstrap.
After a partial failure inspect logs; do not delete volumes to bypass the guard.
Restart an initialized stand without bootstrap:
  docker compose up -d --no-build --pull never --scale worker-general=16 --scale worker-browser=8
  docker compose --profile maintenance up -d --no-build --pull never init-backups backup
Stop without deleting data:
  docker compose --profile maintenance stop web worker-general worker-browser backup
  docker compose stop browser db
Never use down -v. Protect and back up the new volumes and refreshed HH tokens.
See DOCKER_README.md for maintenance. Old recruitment project-name instructions
must be adjusted to recruitment-test. Existing volumes use the new project name.
The deployment script was syntax-checked, not executed on a Docker server here.
"""

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def build(root,out):
    root=root.resolve();out=out.resolve()
    if out.exists():raise SystemExit('Output exists; not overwritten: '+str(out))
    required=['compose.yaml','Dockerfile','docker/container_entry.py','docker/seed_config.py',
              'docker/browser-seccomp.json','recruitment-images.tar.gz',
              'deploy/secrets/gmail_password']
    for name in required:
        if not (root/name).is_file():raise SystemExit('Missing required file: '+name)
    compose=(root/'compose.yaml').read_text(encoding='utf-8-sig')
    compose,count=re.subn(r'(?m)^name:\s*[^\n]+$', 'name: recruitment-test',compose,count=1)
    if count!=1:raise SystemExit('Unexpected Compose project name format')
    compose,count=re.subn(r"(?m)^(\s+BROWSER_MAX_SESSIONS:)\s*[^\n]+$",r"\1 '8'",compose)
    if count!=3:raise SystemExit('Expected exactly three BROWSER_MAX_SESSIONS entries')
    image=root/'recruitment-images.tar.gz'
    digest=sha(image)
    checksum=root/'recruitment-images.tar.gz.sha256'
    if not checksum.is_file() or checksum.read_text().split()[0].lower()!=digest:
        raise SystemExit('Image archive checksum missing or mismatched')
    with tempfile.TemporaryDirectory(prefix='recruitment_private_') as temp:
        seed=Path(temp)/'hh.env'
        # Snapshot current refreshed tokens, not the obsolete seed on the host.
        subprocess.run(['docker','compose','cp','web:/config/hh.env',str(seed)],cwd=root,check=True)
        if not seed.is_file() or seed.stat().st_size==0:raise SystemExit('Current HH config snapshot missing')
        seed.chmod(0o600)
        gmail=(root/'deploy/secrets/gmail_password').read_text(encoding='utf-8').strip()
        if not gmail:raise SystemExit('Empty Gmail secret')
        values={n:secrets.token_hex(32)+'\n' for n in ['db_admin','db_app','db_backup','browser_key','metrics_token']}
        values['gmail_password']=gmail+'\n'
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
            prefix='recruitment_test/'
            def write(name,data):z.writestr(prefix+name,data)
            # Source only. Never include deploy, host .env, databases, dumps or node_modules.
            for f in sorted(root.rglob('*')):
                if not f.is_file():continue
                rel=f.relative_to(root);name=rel.as_posix()
                if any(x in {'deploy','logs','backups','node_modules','.venv','__pycache__','.git'} for x in rel.parts):continue
                if f.name.startswith('.env') or f.suffix in {'.env','.db','.pyc','.dump','.zip','.gz','.tar','.partial','.lock'}:continue
                if name in {'compose.yaml','docker.env','recruitment-images.tar.gz.sha256','START_TEST.sh','START_HERE_TEST.txt'}:continue
                if rel.parts[0] not in {'docker','browser_service','ui'} and len(rel.parts)>1:continue
                if f.name in {'.supervisor.lock','.stop-server'}:continue
                if f==out:continue
                z.write(f,prefix+name)
            write('compose.yaml',compose)
            write('.env','APP_BIND_IP=127.0.0.1\nAPP_PUBLIC_PORT=8765\nSESSION_COOKIE_SECURE=false\nTARGET_PLATFORM=linux/amd64\n')
            for name,value in values.items():write('deploy/secrets/'+name,value)
            write('deploy/secrets/hh_seed',seed.read_bytes())
            write('deploy/backups/.keep','')
            write('START_TEST.sh',START)
            write('START_HERE_TEST.txt',README)
            write('recruitment-images.tar.gz.sha256',digest+'  recruitment-images.tar.gz\n')
            z.write(image,prefix+'recruitment-images.tar.gz',compress_type=zipfile.ZIP_STORED)
        with zipfile.ZipFile(out) as z:
            bad=z.testzip()
            if bad:raise SystemExit('Archive integrity failure: '+bad)
            assert z.read('recruitment_test/compose.yaml').decode()==compose
            assert not any(n.endswith('.dump') or n.endswith('.db') for n in z.namelist())
    print('PRIVATE_BUNDLE_READY:',out.name)
    print('BYTES:',out.stat().st_size)
    print('SHA256:',sha(out))
    print('CONTAINS SECRETS. Transfer only through an approved private channel.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--project',default='.');p.add_argument('--output',default='recruitment-test-private.zip')
    a=p.parse_args();build(Path(a.project),Path(a.output))
