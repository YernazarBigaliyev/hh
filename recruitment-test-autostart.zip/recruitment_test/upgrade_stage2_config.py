"""Upgrade old stage2 configuration without resetting an existing database password.
Stop all processes first. The original file is backed up with its existing secrets.
"""
import os,secrets,subprocess,sys,shutil
from pathlib import Path
from urllib.parse import urlparse
from dotenv import dotenv_values,set_key,unset_key
from psycopg.conninfo import conninfo_to_dict,make_conninfo
root=Path(__file__).resolve().parent

def main():
    runtime=root/'.env.stage2';infra=root/'.env.infrastructure';backup=root/'.env.stage2.before-hardening'
    if not runtime.exists():raise SystemExit('No old .env.stage2; use stage2_setup.py for a fresh install')
    if infra.exists() or backup.exists():raise SystemExit('Upgrade files already exist; no files overwritten')
    old=dotenv_values(runtime);admin=old.get('DATABASE_URL')
    if not admin:raise SystemExit('Old DATABASE_URL is required')
    info=conninfo_to_dict(admin)
    if not info.get('password'):raise SystemExit('Provide the existing administrator password in the old DATABASE_URL')
    key=old.get('BROWSER_WS_PATH') or urlparse(old.get('BROWSER_WS_ENDPOINT','')).path.strip('/')
    if not key:raise SystemExit('Existing browser WebSocket path is required')
    app=secrets.token_hex(24);reader=secrets.token_hex(24)
    pending=root/'.env.infrastructure.pending'
    if pending.exists():raise SystemExit('Pending configuration exists; inspect it before retrying')
    pending.touch(mode=0o600)
    for name,value in {'POSTGRES_PASSWORD':info['password'],'APP_DB_PASSWORD':app,'BACKUP_DB_PASSWORD':reader,
        'PG_ADMIN_URL':admin,'PG_BACKUP_URL':make_conninfo(admin,user='recruitment_backup',password=reader),
        'BROWSER_WS_PATH':key,'INFRA_BIND_IP':old.get('INFRA_BIND_IP','127.0.0.1')}.items():set_key(str(pending),name,value)
    env=dict(os.environ,PG_ADMIN_URL=admin,APP_DB_PASSWORD=app,BACKUP_DB_PASSWORD=reader)
    try:subprocess.run([sys.executable,'bootstrap_server.py'],cwd=root,env=env,check=True,timeout=90)
    except BaseException:
        pending.unlink(missing_ok=True);raise
    pending.replace(infra)
    shutil.copy2(runtime,backup)
    for name in ('POSTGRES_PASSWORD','APP_DB_PASSWORD','BACKUP_DB_PASSWORD','PG_ADMIN_URL','PG_BACKUP_URL','BROWSER_WS_PATH','INFRA_BIND_IP'):
        if name in old:unset_key(str(runtime),name)
    endpoint=urlparse(old.get('BROWSER_WS_ENDPOINT','ws://127.0.0.1:3000'))
    updates={'DATABASE_URL':make_conninfo(admin,user='recruitment_app',password=app),'APP_SCHEMA_MANAGED':'true',
        'METRICS_TOKEN':secrets.token_hex(32),'BROWSER_HEALTH_URL':'http://'+(endpoint.hostname or '127.0.0.1')+':3001/health/ready',
        'DB_POOL_MAX':'6','JOB_MAX_ATTEMPTS':'3','JOB_RETRY_BASE_SECONDS':'5','JOB_RETRY_MAX_SECONDS':'300','STUCK_AFTER_SECONDS':'600'}
    for name,value in updates.items():set_key(str(runtime),name,value)
    for path in (runtime,infra,backup):
        try:path.chmod(0o600)
        except OSError:pass
    print('Upgraded runtime role and schema. Old secrets retained only in protected administrator/backup files. Install native browser dependencies; see NATIVE_README.md.')
if __name__=='__main__':main()
