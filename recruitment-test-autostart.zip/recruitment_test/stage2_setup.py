"""Native PostgreSQL configuration. Does not install PostgreSQL or overwrite files."""
import os,secrets,getpass
from pathlib import Path
from dotenv import set_key
from psycopg.conninfo import make_conninfo

def main():
    root=Path(__file__).resolve().parent
    runtime=root/'.env.stage2';infra=root/'.env.infrastructure'
    if runtime.exists() or infra.exists():raise SystemExit('Configuration exists; not overwritten. Read NATIVE_README.md.')
    admin=os.getenv('NATIVE_PG_ADMIN_URL','').strip()
    if not admin:
        host=input('PostgreSQL host [127.0.0.1]: ').strip() or '127.0.0.1'
        port=input('PostgreSQL port [5432]: ').strip() or '5432'
        db=input('Application database [recruitment]: ').strip() or 'recruitment'
        user=input('PostgreSQL administrator [postgres]: ').strip() or 'postgres'
        password=getpass.getpass('Existing PostgreSQL administrator password: ')
        admin=make_conninfo(host=host,port=port,dbname=db,user=user,password=password)
    app=secrets.token_hex(24);backup=secrets.token_hex(24);key=secrets.token_hex(32)
    runtime_values={
        'DATABASE_URL':make_conninfo(admin,user='recruitment_app',password=app),
        'TASK_QUEUE_BACKEND':'postgres','APP_SCHEMA_MANAGED':'true',
        'BROWSER_WS_ENDPOINT':'ws://127.0.0.1:3000/'+key,
        'BROWSER_HEALTH_URL':'http://127.0.0.1:3001/health/ready',
        'METRICS_TOKEN':secrets.token_hex(32),'CAPTCHA_WAIT_SECONDS':'1800',
        'BROWSER_MAX_SESSIONS':'2','APP_HOST':'0.0.0.0','DB_POOL_MAX':'6',
        'JOB_MAX_ATTEMPTS':'3','JOB_RETRY_BASE_SECONDS':'5','JOB_RETRY_MAX_SECONDS':'300',
        'STUCK_AFTER_SECONDS':'600','BROWSER_SERVICE_MEMORY_MB':'2048','BROWSER_SERVICE_CPU_PERCENT':'50'}
    infra_values={'PG_ADMIN_URL':admin,'APP_DB_PASSWORD':app,'BACKUP_DB_PASSWORD':backup,
        'PG_BACKUP_URL':make_conninfo(admin,user='recruitment_backup',password=backup)}
    for path,values in [(runtime,runtime_values),(infra,infra_values)]:
        path.touch(mode=0o600)
        for name,value in values.items():set_key(str(path),name,value)
        try:path.chmod(0o600)
        except OSError:pass
    print('Native configuration created. Existing PostgreSQL password unchanged. Run native_bootstrap.py --create-db.')
if __name__=='__main__':main()
