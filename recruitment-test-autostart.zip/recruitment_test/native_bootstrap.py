"""Create an explicitly requested application DB, then run administrator bootstrap."""
import argparse,os,subprocess,sys
from pathlib import Path
import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo,conninfo_to_dict
from dotenv import load_dotenv

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--create-db',action='store_true');args=parser.parse_args()
    root=Path(__file__).resolve().parent;load_dotenv(root/'.env.infrastructure')
    admin=os.environ['PG_ADMIN_URL'];name=conninfo_to_dict(admin).get('dbname')
    if not name or name in {'postgres','template0','template1'}:raise SystemExit('Use a dedicated application database, not a maintenance database.')
    if args.create_db:
        maintenance=make_conninfo(admin,dbname=os.getenv('PG_MAINTENANCE_DB','postgres'))
        with psycopg.connect(maintenance,autocommit=True,connect_timeout=5) as con:
            if not con.execute('SELECT 1 FROM pg_database WHERE datname=%s',(name,)).fetchone():
                con.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(name)))
    with psycopg.connect(admin,connect_timeout=5) as con:con.execute('SELECT 1')
    subprocess.run([sys.executable,'bootstrap_server.py'],cwd=root,check=True,timeout=90)
    print('NATIVE_DATABASE_READY')
if __name__=='__main__':main()
