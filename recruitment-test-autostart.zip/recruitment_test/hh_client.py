from __future__ import annotations
import logging, os, time, webbrowser, threading
from functools import wraps
from urllib.parse import urlencode
import requests
from dotenv import set_key, dotenv_values
from token_lock import token_file_lock
from errors import HHUnavailableError
from app_state import APP_STATE, STATE_LOCK
from settings import *

logger = logging.getLogger(__name__)
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": HH_USER_AGENT, "Accept": "application/json"})

AUTH_LOCK=threading.RLock()
_AUTH_GENERATION=0
_AUTH_LAST_ATTEMPT=None
_AUTH_LAST_TIME=0.0
_AUTH_LAST_RESULT=False

def synchronized_auth(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        with AUTH_LOCK:
            with token_file_lock(ENV_PATH):return fn(*args,**kwargs)
    return wrapped

@synchronized_auth
def save_tokens(access_token: str, refresh_token: str | None = None) -> None:
    global _AUTH_GENERATION
    # Persist both values with one atomic replacement, not two interleavable writes.
    import tempfile
    from pathlib import Path
    path=Path(ENV_PATH)
    fd,temp=tempfile.mkstemp(prefix='.hh-token-',dir=str(path.parent))
    os.close(fd)
    try:
        Path(temp).write_bytes(path.read_bytes() if path.exists() else b'')
        set_key(temp,"HH_BEARER",access_token)
        if refresh_token:set_key(temp,"HH_REFRESH_TOKEN",refresh_token)
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)
    os.environ["HH_BEARER"] = access_token
    _AUTH_GENERATION+=1
    SESSION.headers["Authorization"] = f"Bearer {access_token}"
    if refresh_token:
        os.environ["HH_REFRESH_TOKEN"] = refresh_token

@synchronized_auth
def refresh_access_token() -> bool:
    refresh = os.getenv("HH_REFRESH_TOKEN", "").strip()
    if not all([refresh, HH_CLIENT_ID, HH_CLIENT_SECRET]): return False
    try:
        response = requests.post(HH_TOKEN_URL, data={"grant_type":"refresh_token", "refresh_token":refresh, "client_id":HH_CLIENT_ID, "client_secret":HH_CLIENT_SECRET}, timeout=(10, REQUEST_TIMEOUT))
        if response.status_code != 200:
            logger.warning("HH token refresh HTTP %s", response.status_code); return False
        data = response.json(); save_tokens(data["access_token"], data.get("refresh_token") or refresh); return True
    except Exception:
        logger.exception("HH token refresh failed"); return False

@synchronized_auth
def authorize_from_scratch() -> bool:
    if os.getenv('HH_INTERACTIVE_AUTH','false').lower()!='true':
        raise HHUnavailableError('Интерактивная авторизация HH отключена. Настройте токены заранее.')
    if not all([HH_CLIENT_ID, HH_CLIENT_SECRET, HH_REDIRECT_URI]): return False
    webbrowser.open(HH_AUTHORIZE_URL + "?" + urlencode({"response_type":"code", "client_id":HH_CLIENT_ID, "redirect_uri":HH_REDIRECT_URI}))
    code = input("Введите code из адресной строки HH: ").strip()
    if not code: return False
    try:
        response = requests.post(HH_TOKEN_URL, data={"grant_type":"authorization_code", "code":code, "client_id":HH_CLIENT_ID, "client_secret":HH_CLIENT_SECRET, "redirect_uri":HH_REDIRECT_URI}, timeout=(10, REQUEST_TIMEOUT))
        response.raise_for_status(); data = response.json(); save_tokens(data["access_token"], data.get("refresh_token")); return True
    except Exception:
        logger.exception("HH authorization failed"); return False

@synchronized_auth
def ensure_token() -> str | None:
    token = os.getenv("HH_BEARER", "").strip()
    if token: SESSION.headers["Authorization"] = f"Bearer {token}"; return token
    return os.getenv("HH_BEARER") if refresh_access_token() or authorize_from_scratch() else None

def reload_saved_tokens():
    global _AUTH_GENERATION
    values=dotenv_values(ENV_PATH)
    token=values.get('HH_BEARER')
    if token and token!=os.getenv('HH_BEARER',''):
        os.environ['HH_BEARER']=token;_AUTH_GENERATION+=1
    if values.get('HH_REFRESH_TOKEN'):os.environ['HH_REFRESH_TOKEN']=values['HH_REFRESH_TOKEN']

@synchronized_auth
def recover_auth(rejected_token,generation):
    """Only the first rejected request refreshes; late responses reuse new credentials."""
    global _AUTH_LAST_ATTEMPT,_AUTH_LAST_TIME,_AUTH_LAST_RESULT
    with AUTH_LOCK:
        reload_saved_tokens()
        current=os.getenv('HH_BEARER','').strip()
        if current and (current!=rejected_token or generation!=_AUTH_GENERATION):return True
        key=(rejected_token,generation)
        if _AUTH_LAST_ATTEMPT==key and time.monotonic()-_AUTH_LAST_TIME<5:
            return _AUTH_LAST_RESULT
        _AUTH_LAST_ATTEMPT=key
        _AUTH_LAST_RESULT=False
        try:_AUTH_LAST_RESULT=bool(refresh_access_token())
        finally:_AUTH_LAST_TIME=time.monotonic()
        return _AUTH_LAST_RESULT

def hh_get(endpoint: str, params: dict | None = None, reauth: bool = True, retries: int = 3):
    url = endpoint if endpoint.startswith("http") else f"{HH_API_BASE}/{endpoint.lstrip('/')}"
    with AUTH_LOCK:
        token=os.getenv('HH_BEARER','').strip()
        generation=_AUTH_GENERATION
    # Do not mutate a shared requests.Session while other threads are sending.
    headers={"User-Agent":HH_USER_AGENT,"Accept":"application/json"}
    if token:headers['Authorization']='Bearer '+token
    try:
        response = requests.get(url, params=params, headers=headers, timeout=(10, REQUEST_TIMEOUT))
    except (requests.ConnectionError, requests.Timeout) as exc:
        if retries <= 0:
            raise HHUnavailableError("HH временно недоступен. Повторите попытку позже.") from exc
        logger.warning("Сетевая ошибка HH (%s), повтор через 2с, осталось %s", exc, retries)
        time.sleep(2)
        return hh_get(endpoint, params, reauth, retries - 1)
    if response.status_code == 429 and retries > 0:
        try: wait = max(1, int(response.headers.get("Retry-After", "5")))
        except ValueError: wait = 5
        time.sleep(wait); return hh_get(endpoint, params, reauth, retries - 1)
    if response.status_code in (401,403) and reauth:
        if recover_auth(token,generation):return hh_get(endpoint,params,False,retries)
        raise HHUnavailableError('Требуется повторная авторизация HH. Обновите доступ на компьютере сервера и возобновите задачу. Фоновый ввод в консоли отключён.')
    try:
        response.raise_for_status()
    except requests.HTTPError as exc:
        raise HHUnavailableError(f"HH вернул HTTP {response.status_code}.") from exc
    return response

def fetch_active_vacancies(employer_id: str) -> list[dict]:
    result, page = [], 0
    while True:
        logger.info("[STARTUP] Загрузка вакансий HH: страница %s", page + 1)
        data = hh_get("/vacancies", {"employer_id": employer_id, "per_page": 100, "page": page}).json()
        result.extend(data.get("items", [])); page += 1
        if page >= data.get("pages", 0):
            logger.info("[STARTUP] Вакансии загружены: %s", len(result)); return result

def fetch_vacancy_details(vacancy_id: str) -> dict:
    if not vacancy_id.isdigit(): raise ValueError("Некорректный ID вакансии")
    with STATE_LOCK: cached = APP_STATE["vacancy_cache"].get(vacancy_id)
    if cached: return cached
    data = hh_get(f"/vacancies/{vacancy_id}").json()
    with STATE_LOCK: APP_STATE["vacancy_cache"][vacancy_id] = data
    return data

def search_resumes(params: dict) -> dict: return hh_get("/resumes", params).json()
def fetch_resume_details(resume_id: str) -> dict: return hh_get(f"/resumes/{resume_id}").json()
