"""Small process supervisor; browser wait never occupies a general worker."""
import argparse,subprocess,sys,time
from pathlib import Path

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--general',type=int,default=4);parser.add_argument('--browser',type=int,default=2)
    args=parser.parse_args()
    if not 1<=args.general<=16 or not 1<=args.browser<=8:parser.error('general: 1..16; browser: 1..8')
    root=Path(__file__).resolve().parent
    lanes=['general']*args.general+['browser']*args.browser
    def start(lane):return subprocess.Popen([sys.executable,str(root/'stage2_worker.py'),'--lane',lane],cwd=root)
    children=[]
    try:
        children=[start(lane) for lane in lanes]
        while True:
            time.sleep(3)
            for i,child in enumerate(children):
                if child.poll() is not None:
                    print('Restarting worker:',lanes[i],flush=True);children[i]=start(lanes[i])
    except KeyboardInterrupt:pass
    finally:
        for child in children:
            if child.poll() is None:child.terminate()
        for child in children:
            try:child.wait(timeout=10)
            except subprocess.TimeoutExpired:child.kill();child.wait()
if __name__=='__main__':main()
